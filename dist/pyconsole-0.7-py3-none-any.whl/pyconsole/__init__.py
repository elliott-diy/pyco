"""
Console printing, input, and logging functions with colors.\n
Version: 0.7.\n
Made by Duplexes and LemonPi314.\n
https://github.com/Duplexes/pyconsole
"""

from .pyco import *

__version__ = '0.7'