"""
Console printing, input, and logging functions with colors.\n
Made by Duplexes and LemonPi314\n
https://github.com/Duplexes/pyconsole
"""
from pyconsole.pyconsole import *